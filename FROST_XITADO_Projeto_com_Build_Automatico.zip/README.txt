FROST XITADO — projeto Android (Kotlin)

Compatibilidade planejada:
- Android 6.0 ou superior (minSdk 23)
- Android 15 / API 35
- Motorola G54 5G

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Extraia a pasta FrostXitado_Android.
3. No Android Studio, escolha Open e selecione a pasta extraída.
4. Aguarde a sincronização do Gradle.
5. Abra Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste será gerado em app/build/outputs/apk/debug/.

O botão INJETAR é somente demonstrativo. Este projeto não injeta código,
não altera o Free Fire e não implementa trapaças. Os controles de mira/FOV
são apenas controles visuais dentro do próprio aplicativo.
O botão ABRIR FREE FIRE tenta abrir o pacote normal e, se não encontrar,
tenta o Free Fire MAX.


BUILD NA NUVEM (SEM ANDROID STUDIO NO CELULAR)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Abra a aba Actions do repositório.
3. Execute "Build FROST XITADO APK" (Run workflow), ou envie os arquivos para a branch main.
4. Quando terminar, abra a execução concluída e baixe o artefato "FROST-XITADO-debug-APK".
5. Extraia o artefato e instale app-debug.apk no Android.
