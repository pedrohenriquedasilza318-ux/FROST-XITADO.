package com.frostxitado.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 10, 18)
    private val panel = Color.rgb(17, 22, 34)
    private val red = Color.rgb(235, 35, 65)
    private val white = Color.rgb(240, 243, 250)
    private val muted = Color.rgb(153, 163, 183)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val brand = TextView(this).apply {
            text = "FROST XITADO"
            textSize = 27f
            setTextColor(red)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }
        content.addView(brand, matchWrap())
        val subtitle = TextView(this).apply {
            text = "PAINEL DE CONFIGURAÇÕES"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(20))
            letterSpacing = 0.16f
        }
        content.addView(subtitle, matchWrap())

        section(content, "GERAL")
        addSwitch(content, "Mira leve", "Ajuste demonstrativo da interface")
        addSwitch(content, "Mira forte", "Ajuste demonstrativo da interface")
        addSwitch(content, "Mostrar círculo de FOV", "Visualização apenas dentro deste app")
        addSwitch(content, "Tema vermelho", "Aparência do painel")

        section(content, "CONFIGURAÇÕES")
        addSlider(content, "FOV DE DEMONSTRAÇÃO", 10, 100, 45)
        addSlider(content, "SENSIBILIDADE VISUAL", 0, 100, 50)

        val inject = actionButton("INJETAR")
        inject.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Modo demonstração")
                .setMessage("Este botão apenas demonstra a interface. O aplicativo não injeta arquivos nem altera o Free Fire.")
                .setPositiveButton("OK", null)
                .show()
        }
        content.addView(inject, matchWrap().apply { topMargin = dp(18) })

        val launch = actionButton("ABRIR FREE FIRE")
        launch.setOnClickListener { openFreeFire() }
        content.addView(launch, matchWrap().apply { topMargin = dp(10) })

        val footer = TextView(this).apply {
            text = "FROST XITADO  •  VERSÃO 1.0\\nConfigurações visuais independentes"
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        }
        content.addView(footer, matchWrap())

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun section(parent: LinearLayout, title: String) {
        val t = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(3), dp(14), 0, dp(8))
            letterSpacing = 0.12f
        }
        parent.addView(t, matchWrap())
    }

    private fun addSwitch(parent: LinearLayout, title: String, desc: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(12), dp(11))
            background = rounded(panel, 14)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val name = TextView(this).apply {
            text = title; textSize = 15f; setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        val detail = TextView(this).apply {
            text = desc; textSize = 10f; setTextColor(muted)
            setPadding(0, dp(3), 0, 0)
        }
        texts.addView(name); texts.addView(detail)
        card.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply { buttonTintList = android.content.res.ColorStateList.valueOf(red) }
        card.addView(toggle)
        val lp = matchWrap().apply { bottomMargin = dp(8) }
        parent.addView(card, lp)
    }

    private fun addSlider(parent: LinearLayout, title: String, min: Int, max: Int, initial: Int) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            background = rounded(panel, 14)
        }
        val label = TextView(this).apply {
            text = "$title  •  $initial"
            textSize = 12f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(white)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                label.text = "$title  •  ${progress + min}"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        card.addView(label); card.addView(seek)
        parent.addView(card, matchWrap().apply { bottomMargin = dp(9) })
    }

    private fun actionButton(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(15), dp(12), dp(15))
        background = rounded(red, 13)
        isClickable = true
        isFocusable = true
    }

    private fun openFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in packages) {
            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                startActivity(launchIntent)
                return
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Free Fire não encontrado")
            .setMessage("Instale o Free Fire pela loja oficial e tente novamente.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
